USE freelancer
GO
-- UDFs --
DROP FUNCTION IF EXISTS dbo.fn_CalculateServiceFee;
GO
CREATE FUNCTION dbo.fn_CalculateServiceFee (@Amount DECIMAL(15,2), @ServiceChargePercentage DECIMAL(5,2))
RETURNS DECIMAL(15,2)
AS
BEGIN
    RETURN (@Amount * @ServiceChargePercentage / 100);
END;
GO

DROP FUNCTION IF EXISTS dbo.CalculateProjectProfit;
GO
CREATE FUNCTION dbo.CalculateProjectProfit(@ProjectID INT)
RETURNS DECIMAL(15,2)
AS
BEGIN
    DECLARE @Profit DECIMAL(15,2);

    SELECT @Profit = ISNULL(SUM(py.Amount), 0) - ISNULL(SUM(sf.TotalFeeDeducted), 0)
    FROM PROJECTS p
    JOIN MILESTONES m ON p.ProjectID = m.ProjectID
    JOIN PAYMENTS py ON m.MilestoneID = py.MilestoneID
    LEFT JOIN SERVICEFEES sf ON py.PaymentID = sf.PaymentID
    WHERE p.ProjectID = @ProjectID;

    RETURN @Profit;
END;
GO

DROP FUNCTION IF EXISTS dbo.fn_AverageFreelancerRating;
GO
CREATE FUNCTION dbo.fn_AverageFreelancerRating (@FreelancerID INT)
RETURNS DECIMAL(3,2)
AS
BEGIN
    DECLARE @AvgRating DECIMAL(3,2);

    SELECT @AvgRating = AVG(CAST(Rating AS DECIMAL(3,2)))
    FROM dbo.REVIEWS
    WHERE FreelancerID = @FreelancerID;

    RETURN ISNULL(@AvgRating, 0);
END;
GO

DROP FUNCTION IF EXISTS dbo.CalculateClientValueScore;
GO
CREATE FUNCTION dbo.CalculateClientValueScore(@ClientID INT)
RETURNS DECIMAL(5,2)
AS
BEGIN
    DECLARE @Score DECIMAL(5,2);

    SELECT @Score = 
        (LOG(SUM(p.Budget)+1) * 0.5) + 
        (AVG(c.ClientRating) * 0.3) + 
        (COUNT(DISTINCT p.ProjectID) * 0.2)
    FROM CLIENTS c
    LEFT JOIN PROJECTS p ON c.ClientID = p.ClientID
    WHERE c.ClientID = @ClientID;

    RETURN ISNULL(@Score, 0);
END;
GO

-- STORED PROCEDURES --
DROP PROCEDURE IF EXISTS dbo.CalculateFreelancerEarnings;
GO
CREATE PROCEDURE dbo.CalculateFreelancerEarnings (@FreelancerID INT)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        
        IF NOT EXISTS (SELECT 1 FROM dbo.FREELANCERS WHERE FreelancerID = @FreelancerID)
        BEGIN
            RAISERROR('Freelancer with ID %d does not exist', 16, 1, @FreelancerID);
            RETURN;
        END;
        
        DECLARE @TotalEarnings DECIMAL(15,2);

        SELECT @TotalEarnings = SUM(P.Amount)
        FROM dbo.PAYMENTS P
        JOIN dbo.MILESTONES M ON P.MilestoneID = M.MilestoneID
        JOIN dbo.PROJECTS PR ON M.ProjectID = PR.ProjectID
        JOIN dbo.TEAMS_FREELANCERS TF ON PR.TeamID = TF.TeamID
        WHERE M.Status = 'Completed'
        AND TF.FreelancerID = @FreelancerID;

        UPDATE dbo.FREELANCERS
        SET TotalEarnings = ISNULL(@TotalEarnings, 0)
        WHERE FreelancerID = @FreelancerID;

        COMMIT TRANSACTION;
        
        SELECT @TotalEarnings AS TotalEarnings;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
            
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO

DROP PROCEDURE IF EXISTS dbo.AddServiceFee;
GO
CREATE PROCEDURE dbo.AddServiceFee (
    @PaymentID INT, 
    @ServiceChargePercentage DECIMAL(5,2), 
    @TotalFee DECIMAL(15,2)
)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Validate input parameters
        IF @PaymentID IS NULL OR @ServiceChargePercentage IS NULL OR @TotalFee IS NULL
        BEGIN
            RAISERROR('None of the parameters can be NULL', 16, 1);
            RETURN;
        END;
        
        IF NOT EXISTS (SELECT 1 FROM dbo.PAYMENTS WHERE PaymentID = @PaymentID)
        BEGIN
            RAISERROR('Payment with ID %d does not exist', 16, 1, @PaymentID);
            RETURN;
        END;
        
        IF @TotalFee < 0
        BEGIN
            RAISERROR('Total fee cannot be negative', 16, 1);
            RETURN;
        END;
        
        -- Check if payment has enough amount for the fee
        DECLARE @PaymentAmount DECIMAL(15,2);
        SELECT @PaymentAmount = Amount FROM dbo.PAYMENTS WHERE PaymentID = @PaymentID;
        
        IF @TotalFee > @PaymentAmount
        BEGIN
            RAISERROR('Service fee cannot be greater than payment amount', 16, 1);
            RETURN;
        END;

        INSERT INTO dbo.SERVICEFEES (ServiceChargePercentage, TotalFeeDeducted, PaymentID)
        VALUES (@ServiceChargePercentage, @TotalFee, @PaymentID);

        UPDATE dbo.PAYMENTS
        SET Amount = Amount - @TotalFee
        WHERE PaymentID = @PaymentID;

        COMMIT TRANSACTION;
        
        SELECT 'Service Fee Added Successfully' AS Status;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
            
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO

DROP PROCEDURE IF EXISTS dbo.RecordPayment;
GO
CREATE PROCEDURE dbo.RecordPayment (
    @MilestoneID INT, 
    @Amount DECIMAL(15,2), 
    @PaymentMethod NVARCHAR(50), 
    @PaymentStatus NVARCHAR(50)
)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Validate input parameters
        IF @MilestoneID IS NULL OR @Amount IS NULL OR @PaymentMethod IS NULL OR @PaymentStatus IS NULL
        BEGIN
            RAISERROR('None of the parameters can be NULL', 16, 1);
            RETURN;
        END;
        
        IF NOT EXISTS (SELECT 1 FROM dbo.MILESTONES WHERE MilestoneID = @MilestoneID)
        BEGIN
            RAISERROR('Milestone with ID %d does not exist', 16, 1, @MilestoneID);
            RETURN;
        END;
        
        IF @Amount <= 0
        BEGIN
            RAISERROR('Payment amount must be positive', 16, 1);
            RETURN;
        END;
        
        DECLARE @PaymentID INT;
        DECLARE @ServiceFee DECIMAL(15,2) = dbo.fn_CalculateServiceFee(@Amount, 5);
        DECLARE @FinalAmount DECIMAL(15,2) = @Amount - @ServiceFee;

        INSERT INTO dbo.PAYMENTS (PaymentDate, Amount, PaymentMethod, PaymentStatus, MilestoneID)
        VALUES (GETDATE(), @FinalAmount, @PaymentMethod, @PaymentStatus, @MilestoneID);

        SET @PaymentID = SCOPE_IDENTITY();

        EXEC dbo.AddServiceFee @PaymentID, 5, @ServiceFee;

        COMMIT TRANSACTION;
        
        SELECT @PaymentID AS PaymentID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
            
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO

-- VIEWS --
DROP VIEW IF EXISTS dbo.FreelancerEarningsOverview;
GO
CREATE VIEW dbo.FreelancerEarningsOverview AS
SELECT
    F.FreelancerID,
    F.FirstName + ' ' + F.LastName AS FreelancerName,
    F.TotalEarnings,
    F.AvailabilityStatus,
    dbo.fn_AverageFreelancerRating(F.FreelancerID) AS AvgRating
FROM dbo.FREELANCERS F;
GO

DROP VIEW IF EXISTS dbo.ClientFinancialSummary;
GO
CREATE VIEW dbo.ClientFinancialSummary AS
SELECT 
    c.ClientID,
    c.CompanyName,
    COUNT(p.ProjectID) AS TotalProjects,
    SUM(p.Budget) AS TotalBudget,
    SUM(py.Amount) AS TotalPaid,
    AVG(p.Budget) AS AvgProjectSize,
    MAX(c.ClientRating) AS ClientRating,
    dbo.CalculateClientValueScore(c.ClientID) AS ClientValueScore
FROM CLIENTS c
LEFT JOIN PROJECTS p ON c.ClientID = p.ClientID
LEFT JOIN MILESTONES m ON p.ProjectID = m.ProjectID
LEFT JOIN PAYMENTS py ON m.MilestoneID = py.MilestoneID
GROUP BY c.ClientID, c.CompanyName, c.ClientRating;
GO

DROP VIEW IF EXISTS dbo.PlatformHealthDashboard;
GO
CREATE VIEW dbo.PlatformHealthDashboard AS
SELECT
    (SELECT COUNT(*) FROM FREELANCERS WHERE AvailabilityStatus = 'Available') AS ActiveFreelancers,
    (SELECT COUNT(*) FROM CLIENTS) AS ActiveClients,
    COUNT(DISTINCT p.ProjectID) AS ActiveProjects,
    SUM(py.Amount) AS YTDEarnings,
    AVG(f.Rating) AS AvgFreelancerRating,
    AVG(c.ClientRating) AS AvgClientRating
FROM PROJECTS p
LEFT JOIN MILESTONES m ON p.ProjectID = m.ProjectID
LEFT JOIN PAYMENTS py ON m.MilestoneID = py.MilestoneID
LEFT JOIN TEAMS t ON p.TeamID = t.TeamID
LEFT JOIN TEAMS_FREELANCERS tf ON t.TeamID = tf.TeamID
LEFT JOIN FREELANCERS f ON tf.FreelancerID = f.FreelancerID
LEFT JOIN CLIENTS c ON p.ClientID = c.ClientID
WHERE p.Status IN ('Open', 'In Progress');
GO

DROP VIEW IF EXISTS dbo.ActiveClientSubscriptions;
GO
CREATE VIEW dbo.ActiveClientSubscriptions AS
SELECT 
    C.CompanyName,
    C.FirstName + ' ' + C.LastName AS ClientName,
    S.PlanType,
    CS.StartDate,
    CS.EndDate,
    CS.PaymentStatus
FROM dbo.CLIENTS C
JOIN dbo.CLIENT_SUBSCRIPTIONS CS ON C.ClientID = CS.ClientID
JOIN dbo.SUBSCRIPTION_PLANS S ON CS.SubscriptionID = S.SubscriptionID
WHERE CS.EndDate > GETDATE() AND CS.PaymentStatus = 'Completed';
GO

-- TRIGGERS --
DROP TRIGGER IF EXISTS dbo.trg_UpdateFreelancerStatusAfterTaskCompletion;
GO
CREATE TRIGGER dbo.trg_UpdateFreelancerStatusAfterTaskCompletion
ON dbo.TASKS
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        -- Only proceed if Status column was updated
        IF NOT UPDATE(Status)
            RETURN;
            
        BEGIN TRANSACTION;
        
        -- Update freelancer status to Available if all their tasks are completed
        UPDATE f
        SET AvailabilityStatus = 'Available'
        FROM dbo.FREELANCERS f
        INNER JOIN (
            SELECT FreelancerID 
            FROM inserted 
            GROUP BY FreelancerID 
            HAVING COUNT(*) = SUM(CASE WHEN Status = 'Completed' THEN 1 ELSE 0 END)
        ) AS completed_freelancers ON f.FreelancerID = completed_freelancers.FreelancerID
        WHERE f.AvailabilityStatus <> 'Available';

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
            
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO