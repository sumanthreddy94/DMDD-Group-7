USE freelancer;
GO

-- Create database master key if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE name = '##MS_DatabaseMasterKey##')
BEGIN
    CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'YourStrongPassword123!';
END
GO

-- Create certificate for encryption
IF NOT EXISTS (SELECT * FROM sys.certificates WHERE name = 'FreelancerDataCert')
BEGIN
    CREATE CERTIFICATE FreelancerDataCert WITH SUBJECT = 'Freelancer Sensitive Data Encryption';
END
GO

-- Create symmetric key for encryption
IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE name = 'FreelancerSensitiveDataKey')
BEGIN
    CREATE SYMMETRIC KEY FreelancerSensitiveDataKey
    WITH ALGORITHM = AES_256
    ENCRYPTION BY CERTIFICATE FreelancerDataCert;
END
GO

-- Add encrypted columns for sensitive data
IF COL_LENGTH('dbo.FREELANCERS', 'EIN_Encrypted') IS NULL
BEGIN
    ALTER TABLE dbo.FREELANCERS
    ADD EIN_Encrypted VARBINARY(256);
END
GO

IF COL_LENGTH('dbo.PAYMENTS', 'Last_Four_Digits_Encrypted') IS NULL
BEGIN
    ALTER TABLE dbo.PAYMENTS
    ADD Last_Four_Digits_Encrypted VARBINARY(256);
END
GO

-- Drop the procedure if it already exists
IF OBJECT_ID('EncryptData', 'P') IS NOT NULL
    DROP PROCEDURE EncryptData;
GO

-- Create a new stored procedure for encrypting data
CREATE PROCEDURE EncryptData
    @plainText NVARCHAR(100),
    @encryptedData VARBINARY(128) OUTPUT
AS
BEGIN
    OPEN SYMMETRIC KEY FreelancerSensitiveDataKey 
        DECRYPTION BY CERTIFICATE FreelancerDataCert;

    SET @encryptedData = EncryptByKey(
        Key_GUID('FreelancerSensitiveDataKey'), 
        @plainText
    );

    CLOSE SYMMETRIC KEY FreelancerSensitiveDataKey;
END
GO

-- Drop the procedure if it already exists
IF OBJECT_ID('DecryptData', 'P') IS NOT NULL
    DROP PROCEDURE DecryptData;
GO

-- Create a stored procedure for decryption
CREATE PROCEDURE DecryptData
    @encryptedData VARBINARY(128),
    @plainText NVARCHAR(100) OUTPUT
AS
BEGIN
    OPEN SYMMETRIC KEY FreelancerSensitiveDataKey 
        DECRYPTION BY CERTIFICATE FreelancerDataCert;

    SET @plainText = CONVERT(NVARCHAR(100), DecryptByKey(@encryptedData));

    CLOSE SYMMETRIC KEY FreelancerSensitiveDataKey;
END
GO

-- Encrypt existing freelancer data
OPEN SYMMETRIC KEY FreelancerSensitiveDataKey
DECRYPTION BY CERTIFICATE FreelancerDataCert;

UPDATE dbo.FREELANCERS
SET 
    EIN_Encrypted = ENCRYPTBYKEY(KEY_GUID('FreelancerSensitiveDataKey'), EIN);

-- Encrypt existing payment data
UPDATE dbo.PAYMENTS
SET 
    Last_Four_Digits_Encrypted = ENCRYPTBYKEY(KEY_GUID('FreelancerSensitiveDataKey'), Last_Four_Digits);

CLOSE SYMMETRIC KEY FreelancerSensitiveDataKey;
GO

-- Remove views that use functions (since UDFs can't open keys)
-- You can retrieve decrypted data using stored procedures instead

-- Create role for data protection
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'DataProtectionOfficer')
BEGIN
    CREATE ROLE DataProtectionOfficer;
END
GO

-- You may instead grant EXECUTE on DecryptData procedure to this role
GRANT EXECUTE ON DecryptData TO DataProtectionOfficer;
GO

-- Deny direct access to encrypted columns
DENY SELECT ON dbo.FREELANCERS(EIN_Encrypted) TO PUBLIC;
DENY SELECT ON dbo.PAYMENTS(Last_Four_Digits_Encrypted) TO PUBLIC;
GO

-- Declare variables
DECLARE @encryptedEIN VARBINARY(256);
DECLARE @decryptedEIN NVARCHAR(100);

DECLARE @encryptedDigits VARBINARY(256);
DECLARE @decryptedDigits NVARCHAR(100);

-- Get encrypted values first
SELECT TOP 1 @encryptedEIN = EIN_Encrypted FROM dbo.FREELANCERS;
SELECT TOP 1 @encryptedDigits = Last_Four_Digits_Encrypted FROM dbo.PAYMENTS;

-- Decrypt using stored procedure
EXEC DecryptData @encryptedData = @encryptedEIN, @plainText = @decryptedEIN OUTPUT;
EXEC DecryptData @encryptedData = @encryptedDigits, @plainText = @decryptedDigits OUTPUT;

-- Show results
SELECT @decryptedEIN AS DecryptedEIN;
SELECT @decryptedDigits AS DecryptedLastFourDigits;