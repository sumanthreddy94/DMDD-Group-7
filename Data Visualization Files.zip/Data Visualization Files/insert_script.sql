USE freelancer
GO
-- Insert Admin Users
INSERT INTO dbo.ADMIN_USERS (FullName, Email, Admin_Role, AccessLevel)
VALUES 
('John Smith', 'john.smith@freelancer.com', 'Super Admin', 5),
('Sarah Johnson', 'sarah.johnson@freelancer.com', 'Manager', 3),
('Michael Brown', 'michael.brown@freelancer.com', 'Support', 2);

-- Insert Reports
INSERT INTO dbo.REPORTS (ReportType, DownloadURL, AdminID)
VALUES 
('Monthly Earnings', 'https://freelancer.com/reports/earnings_june2023.pdf', 1),
('User Activity', 'https://freelancer.com/reports/activity_june2023.pdf', 2),
('System Performance', 'https://freelancer.com/reports/performance_june2023.pdf', 3);

-- Insert Teams
INSERT INTO dbo.TEAMS (TeamRole)
VALUES 
('Web Development'),
('Mobile Development'),
('Data Science'),
('UI/UX Design'),
('Quality Assurance');

-- Insert Freelancers
INSERT INTO dbo.FREELANCERS (FirstName, LastName, Phone, ProfilePictureURL, Skills, ExperienceLevel, Rating, AvailabilityStatus, PortfolioURL, EIN, TotalEarnings)
VALUES 
('Alex', 'Johnson', '555-123-4567', 'https://freelancer.com/profiles/alex.jpg', 'JavaScript,React,Node.js', 'Expert', 4.8, 'Available', 'https://alexjohnson.dev', '12-3456789', 12500.00),
('Maria', 'Garcia', '555-234-5678', 'https://freelancer.com/profiles/maria.jpg', 'Python,Django,ML', 'Intermediate', 4.5, 'Busy', 'https://mariagarcia.dev', '23-4567890', 8500.00),
('James', 'Smith', '555-345-6789', 'https://freelancer.com/profiles/james.jpg', 'Swift,iOS,UI/UX', 'Expert', 4.9, 'Available', 'https://jamessmith.dev', '34-5678901', 18200.00),
('Emily', 'Wilson', '555-456-7890', 'https://freelancer.com/profiles/emily.jpg', 'Java,Spring,SQL', 'Intermediate', 4.2, 'On Vacation', 'https://emilywilson.dev', '45-6789012', 7600.00),
('David', 'Lee', '555-567-8901', 'https://freelancer.com/profiles/david.jpg', 'C#,.NET,Azure', 'Expert', 4.7, 'Available', 'https://davidlee.dev', '56-7890123', 15300.00);

-- Insert Team-Freelancer Assignments
INSERT INTO dbo.TEAMS_FREELANCERS (TeamID, FreelancerID)
VALUES 
(1, 1), -- Web Dev
(1, 5), -- Web Dev
(2, 3), -- Mobile Dev
(3, 2), -- Data Science
(4, 3), -- UI/UX
(5, 4); -- QA

-- Insert Clients
INSERT INTO dbo.CLIENTS (CompanyName, FirstName, LastName, Email, Phone, CompanyWebsiteURL, ClientRating, IndustryType, TotalProjectsPosted)
VALUES 
('Tech Solutions Inc', 'Robert', 'Brown', 'robert@techsolutions.com', '555-111-2222', 'https://techsolutions.com', 4.7, 'Technology', 8),
('Creative Designs LLC', 'Jennifer', 'Davis', 'jennifer@creativedesigns.com', '555-222-3333', 'https://creativedesigns.com', 4.9, 'Design', 12),
('Data Analytics Co', 'Thomas', 'Miller', 'thomas@dataanalytics.com', '555-333-4444', 'https://dataanalytics.com', 4.5, 'Data Services', 5),
('Mobile Innovations', 'Lisa', 'Wilson', 'lisa@mobileinnovations.com', '555-444-5555', 'https://mobileinnovations.com', 4.8, 'Mobile Development', 9),
('Global Enterprises', 'William', 'Taylor', 'william@globalenterprises.com', '555-555-6666', 'https://globalenterprises.com', 4.6, 'Consulting', 15);

-- Insert Subscription Plans
INSERT INTO dbo.SUBSCRIPTION_PLANS (PlanType)
VALUES 
('Basic'),
('Professional'),
('Enterprise'),
('Premium');

-- Insert Client Subscriptions
INSERT INTO dbo.CLIENT_SUBSCRIPTIONS (ClientID, SubscriptionID, StartDate, EndDate, PaymentStatus)
VALUES 
(1, 3, '2023-01-15', '2024-01-15', 'Completed'),
(2, 4, '2023-03-10', '2024-03-10', 'Completed'),
(3, 2, '2023-05-20', '2024-05-20', 'Completed'),
(4, 3, '2023-02-05', '2024-02-05', 'Completed'),
(5, 4, '2023-04-15', '2024-04-15', 'Completed');

-- Insert Freelancer Subscriptions
INSERT INTO dbo.FREELANCER_SUBSCRIPTIONS (FreelancerID, SubscriptionID, StartDate, EndDate, PaymentStatus)
VALUES 
(1, 2, '2023-01-10', '2024-01-10', 'Completed'),
(2, 1, '2023-02-15', '2024-02-15', 'Completed'),
(3, 3, '2023-03-20', '2024-03-20', 'Completed'),
(4, 1, '2023-04-25', '2024-04-25', 'Completed'),
(5, 2, '2023-05-30', '2024-05-30', 'Completed');

-- Insert Projects
INSERT INTO dbo.PROJECTS (ProjectName, Description, Budget, Deadline, SkillsRequired, Status, TotalApplicants, ClientID, TeamID)
VALUES 
('E-commerce Website', 'Build a responsive e-commerce platform', 15000.00, '2023-08-30', 'React,Node.js,MongoDB', 'In Progress', 5, 1, 1),
('Mobile Banking App', 'Develop a secure banking application', 25000.00, '2023-09-15', 'Swift,Kotlin,Firebase', 'Open', 8, 4, 2),
('Data Visualization Dashboard', 'Create interactive data visualizations', 12000.00, '2023-07-20', 'Python,D3.js,SQL', 'Completed', 3, 3, 3),
('UI/UX Redesign', 'Redesign company website and mobile app', 18000.00, '2023-08-10', 'Figma,Adobe XD,Sketch', 'In Progress', 6, 2, 4),
('Automated Testing Suite', 'Build comprehensive test automation', 9500.00, '2023-07-30', 'Selenium,JUnit,Cypress', 'Open', 4, 5, 5);

-- Insert Milestones
INSERT INTO dbo.MILESTONES (MilestoneName, DueDate, Status, ProjectID)
VALUES 
('Requirements Finalized', '2023-06-15', 'Completed', 1),
('UI Prototype Completed', '2023-06-30', 'Completed', 1),
('Backend Development', '2023-07-31', 'In Progress', 1),
('Initial App Design', '2023-06-20', 'Completed', 2),
('Core Functionality', '2023-08-15', 'Pending', 2),
('Data Model Complete', '2023-05-30', 'Completed', 3),
('Final Delivery', '2023-07-15', 'Completed', 3),
('Wireframes Approved', '2023-06-10', 'Completed', 4),
('Test Plan Approved', '2023-06-25', 'Completed', 5);

-- Insert Payments
INSERT INTO dbo.PAYMENTS (PaymentDate, Amount, PaymentMethod, PaymentStatus, MilestoneID, Last_Four_Digits)
VALUES 
('2023-06-20', 3000.00, 'Credit Card', 'Completed', 1, '1234'),
('2023-07-05', 4500.00, 'Bank Transfer', 'Completed', 2, '5678'),
('2023-05-25', 2000.00, 'PayPal', 'Completed', 6, '9012'),
('2023-06-15', 1500.00, 'Credit Card', 'Completed', 8, '3456'),
('2023-06-28', 1200.00, 'Bank Transfer', 'Completed', 9, '7890');

-- Insert Service Fees
INSERT INTO dbo.SERVICEFEES (ServiceChargePercentage, TotalFeeDeducted, PaymentID)
VALUES 
(5.00, 150.00, 1),
(5.00, 225.00, 2),
(5.00, 100.00, 3),
(5.00, 75.00, 4),
(5.00, 60.00, 5);

-- Insert Events
INSERT INTO dbo.EVENTS (EventName, Description, MilestoneID, PaymentID)
VALUES 
('Milestone Completed', 'Requirements gathering phase completed', 1, 1),
('Payment Processed', 'Payment for UI prototype completed', 2, 2),
('Project Completed', 'Data visualization project delivered', 3, NULL),
('Payment Received', 'Initial payment for wireframes', NULL, 4),
('Test Plan Approved', 'Client approved the test plan', 9, NULL);

-- Insert Notifications
INSERT INTO dbo.NOTIFICATIONS (Message, NotificationType, Status, EventID)
VALUES 
('Milestone 1 completed for Project 1', 'Milestone', 'Read', 1),
('Payment of $3000 received', 'Payment', 'Read', 2),
('Project 3 marked as completed', 'Project', 'Unread', 3),
('New message from client', 'Message', 'Unread', NULL),
('Test plan requires your review', 'Approval', 'Read', 5);

-- Insert Reviews
INSERT INTO dbo.REVIEWS (Rating, ReviewText, ReviewDate, ClientID, FreelancerID, MilestoneID)
VALUES 
(5, 'Excellent work on the requirements phase!', '2023-06-21', 1, 1, 1),
(4, 'Good prototype, just a few minor changes needed', '2023-07-06', 1, 1, 2),
(5, 'Perfect delivery, exceeded our expectations', '2023-07-16', 3, 2, 3),
(4, 'Wireframes were exactly what we needed', '2023-06-16', 2, 3, 8),
(5, 'Test plan was comprehensive and well-documented', '2023-06-29', 5, 4, 9);

-- Insert Tasks
INSERT INTO dbo.TASKS (PriorityLevel, Status, DueDate, CompletionDate, TaskDescription, ProjectID, MilestoneID, FreelancerID)
VALUES 
(1, 'Completed', '2023-06-10', '2023-06-08', 'Gather client requirements', 1, 1, 1),
(2, 'Completed', '2023-06-25', '2023-06-28', 'Create initial UI mockups', 1, 2, 1),
(1, 'In Progress', '2023-07-15', NULL, 'Develop authentication module', 1, 3, 5),
(3, 'Pending', '2023-08-01', NULL, 'Implement payment gateway', 2, 5, 3),
(2, 'Completed', '2023-05-20', '2023-05-18', 'Design database schema', 3, 6, 2);

-- Insert Applications
INSERT INTO dbo.APPLICATIONS (Coverletter, ExpectedPay, Status, ProjectID, FreelancerID)
VALUES 
('I have extensive experience with e-commerce platforms', 14000.00, 'Accepted', 1, 1),
('I specialize in mobile banking security', 23000.00, 'Pending', 2, 3),
('Data visualization is my expertise', 11000.00, 'Accepted', 3, 2),
('I can deliver pixel-perfect designs', 17000.00, 'Pending', 4, 3),
('I have 5 years of test automation experience', 9000.00, 'Accepted', 5, 4);

-- Insert Disputes
INSERT INTO dbo.DISPUTES (Reason, Status, ResolutionDetails, FreelancerID, ClientID)
VALUES 
('Delayed delivery', 'Resolved', 'Extended deadline by 1 week', 4, 5),
('Quality concerns', 'Open', NULL, 2, 3),
('Payment discrepancy', 'In Progress', 'Partial refund issued', 1, 1);

