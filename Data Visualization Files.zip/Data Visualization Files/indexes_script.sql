USE freelancer
GO
-- For PROJECTS table
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_PROJECTS_ClientID' AND object_id = OBJECT_ID('dbo.PROJECTS'))
    DROP INDEX IX_PROJECTS_ClientID ON dbo.PROJECTS;
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_PROJECTS_TeamID' AND object_id = OBJECT_ID('dbo.PROJECTS'))
    DROP INDEX IX_PROJECTS_TeamID ON dbo.PROJECTS;

-- For MILESTONES table
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_MILESTONES_ProjectID' AND object_id = OBJECT_ID('dbo.MILESTONES'))
    DROP INDEX IX_MILESTONES_ProjectID ON dbo.MILESTONES;

-- For PAYMENTS table
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_PAYMENTS_MilestoneID' AND object_id = OBJECT_ID('dbo.PAYMENTS'))
    DROP INDEX IX_PAYMENTS_MilestoneID ON dbo.PAYMENTS;

-- For SERVICEFEES table
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_SERVICEFEES_PaymentID' AND object_id = OBJECT_ID('dbo.SERVICEFEES'))
    DROP INDEX IX_SERVICEFEES_PaymentID ON dbo.SERVICEFEES;

-- For TEAMS_FREELANCERS table
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_TEAMS_FREELANCERS_FreelancerID' AND object_id = OBJECT_ID('dbo.TEAMS_FREELANCERS'))
    DROP INDEX IX_TEAMS_FREELANCERS_FreelancerID ON dbo.TEAMS_FREELANCERS;

-- For FreelancerEarningsOverview view
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_FREELANCERS_AvailabilityStatus' AND object_id = OBJECT_ID('dbo.FREELANCERS'))
    DROP INDEX IX_FREELANCERS_AvailabilityStatus ON dbo.FREELANCERS;

-- For CalculateFreelancerEarnings procedure
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_MILESTONES_Status_ProjectID' AND object_id = OBJECT_ID('dbo.MILESTONES'))
    DROP INDEX IX_MILESTONES_Status_ProjectID ON dbo.MILESTONES;

-- For PlatformHealthDashboard view
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_PROJECTS_Status' AND object_id = OBJECT_ID('dbo.PROJECTS'))
    DROP INDEX IX_PROJECTS_Status ON dbo.PROJECTS;

-- For ClientFinancialSummary view
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CLIENTS_ClientRating' AND object_id = OBJECT_ID('dbo.CLIENTS'))
    DROP INDEX IX_CLIENTS_ClientRating ON dbo.CLIENTS;

-- For frequent payment queries
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_PAYMENTS_PaymentDate' AND object_id = OBJECT_ID('dbo.PAYMENTS'))
    DROP INDEX IX_PAYMENTS_PaymentDate ON dbo.PAYMENTS;

-- For project-milestone-payment joins
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_PROJECT_MILESTONE_PAYMENT' AND object_id = OBJECT_ID('dbo.PROJECTS'))
    DROP INDEX IX_PROJECT_MILESTONE_PAYMENT ON dbo.PROJECTS;

-- For team-freelancer relationships
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_TEAMS_FREELANCERS_COMPOSITE' AND object_id = OBJECT_ID('dbo.TEAMS_FREELANCERS'))
    DROP INDEX IX_TEAMS_FREELANCERS_COMPOSITE ON dbo.TEAMS_FREELANCERS;

-- For ActiveClientSubscriptions view
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CLIENT_SUBSCRIPTIONS_Active' AND object_id = OBJECT_ID('dbo.CLIENT_SUBSCRIPTIONS'))
    DROP INDEX IX_CLIENT_SUBSCRIPTIONS_Active ON dbo.CLIENT_SUBSCRIPTIONS;

-- For tasks trigger
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_TASKS_FreelancerID_Status' AND object_id = OBJECT_ID('dbo.TASKS'))
    DROP INDEX IX_TASKS_FreelancerID_Status ON dbo.TASKS;

-- Now create all the indexes
-- For PROJECTS table
CREATE NONCLUSTERED INDEX IX_PROJECTS_ClientID ON dbo.PROJECTS(ClientID);
CREATE NONCLUSTERED INDEX IX_PROJECTS_TeamID ON dbo.PROJECTS(TeamID);

-- For MILESTONES table
CREATE NONCLUSTERED INDEX IX_MILESTONES_ProjectID ON dbo.MILESTONES(ProjectID);

-- For PAYMENTS table
CREATE NONCLUSTERED INDEX IX_PAYMENTS_MilestoneID ON dbo.PAYMENTS(MilestoneID);

-- For SERVICEFEES table
CREATE NONCLUSTERED INDEX IX_SERVICEFEES_PaymentID ON dbo.SERVICEFEES(PaymentID);

-- For TEAMS_FREELANCERS table
CREATE NONCLUSTERED INDEX IX_TEAMS_FREELANCERS_FreelancerID ON dbo.TEAMS_FREELANCERS(FreelancerID);

-- For FreelancerEarningsOverview view
CREATE NONCLUSTERED INDEX IX_FREELANCERS_AvailabilityStatus ON dbo.FREELANCERS(AvailabilityStatus)
INCLUDE (FirstName, LastName, TotalEarnings);

-- For CalculateFreelancerEarnings procedure
CREATE NONCLUSTERED INDEX IX_MILESTONES_Status_ProjectID ON dbo.MILESTONES(Status, ProjectID)
INCLUDE (MilestoneID);

-- For PlatformHealthDashboard view
CREATE NONCLUSTERED INDEX IX_PROJECTS_Status ON dbo.PROJECTS(Status)
INCLUDE (ProjectID, TeamID, ClientID);

-- For ClientFinancialSummary view
CREATE NONCLUSTERED INDEX IX_CLIENTS_ClientRating ON dbo.CLIENTS(ClientRating)
INCLUDE (ClientID, CompanyName);

-- For frequent payment queries
CREATE NONCLUSTERED INDEX IX_PAYMENTS_PaymentDate ON dbo.PAYMENTS(PaymentDate)
INCLUDE (Amount, PaymentStatus, MilestoneID);

-- For project-milestone-payment joins
CREATE NONCLUSTERED INDEX IX_PROJECT_MILESTONE_PAYMENT ON dbo.PROJECTS(ProjectID)
INCLUDE (TeamID, ClientID, Budget);

-- For team-freelancer relationships
CREATE NONCLUSTERED INDEX IX_TEAMS_FREELANCERS_COMPOSITE ON dbo.TEAMS_FREELANCERS(TeamID, FreelancerID);

-- For ActiveClientSubscriptions view
CREATE NONCLUSTERED INDEX IX_CLIENT_SUBSCRIPTIONS_Active ON dbo.CLIENT_SUBSCRIPTIONS(EndDate, PaymentStatus)
INCLUDE (ClientID, SubscriptionID, StartDate);

-- For tasks trigger
CREATE NONCLUSTERED INDEX IX_TASKS_FreelancerID_Status ON dbo.TASKS(FreelancerID, Status);